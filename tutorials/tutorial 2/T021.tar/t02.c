#include <stdio.h>

#define MAX_SIZE  32

#define C_OK             0
#define C_ERR_ARR_FULL  -1

int  getStuData(int*, float*);
void printStuData(int*, float*, int);
void printErrorMsg(int);


int main()
{

  return(0);
}


