#include<stdio.h>

int main(int argc, char* argv[]){
  int x;
 return 0;
}
